<?php
defined('BASEPATH') or exit('No direct script access allowed');

// ! Password incryption - FurRs

class Common
{
    public $num = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
}
