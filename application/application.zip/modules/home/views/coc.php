<?php
// Page data
$title    = !empty($page_title) ? ucfirst($page_title) : 'Memorandum and COC';
$pdf_path = !empty($active_document) ? "dist/pdf/$active_document.pdf" : 'dist/pdf/IDEAL TECH STAFFING - Code of Conduct and Discipline.pdf';
$pdf_url  = base_url($pdf_path);
?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2 align-items-center">
            <div class="col-sm-6">
                <h1 class="m-0"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>
                <nav aria-label="Breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url() ?>" aria-label="Home">
                                <i class="fa fa-home" aria-hidden="true"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Memorandum and COC</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Main content -->
<div class="content" <?= empty($page_title) ? "style='padding-top:15px;'" : "" ?>>
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="card card-outline card-primary">
                    <div class="card-header d-flex flex-wrap gap-2 align-items-center">
                        <span class="mr-auto font-weight-bold">Document viewer</span>
                        <div class="btn-group" role="group" aria-label="Document actions">
                            <!-- add another one-legalties-hr-and-outsourcing-service-opc-presmat-2024-1.pdf -->
                            <a class="btn btn-sm m-r-5 <?= empty($active_document) ? "btn-primary" : "btn-outline-primary " ?>" href="<?= base_url('home/coc') ?>">
                                COC
                            </a>

                            <!-- add another one-legalties-hr-and-outsourcing-service-opc-presmat-2024-1.pdf -->
                            <a class="btn btn-sm  m-r-5 <?= ($active_document == 'one-legalties-hr-and-outsourcing-service-opc-presmat-2024-1') ? 'btn-primary' : 'btn-outline-primary' ?>" href="<?= base_url('home/coc/one-legalties-hr-and-outsourcing-service-opc-presmat-2024-1') ?>">
                                One Legalties HR and Outsourcing Service OPC Presmat 2024-1
                            </a>

                            <a class="btn btn-sm btn-outline-primary" href="<?= $pdf_url ?>" target="_blank" rel="noopener" title="Open in new tab">
                                <i class="fa fa-external-link-alt" aria-hidden="true"></i> Open
                            </a>
                        </div>
                    </div>

                    <div class="card-body p-0">
                        <!-- viewer wrapper for full-height -->
                        <div id="pdfWrapper" class="position-relative" style="height: calc(100vh - 260px); min-height: 420px;">

                            <!-- PDF Object -->
                            <object data="<?= $pdf_url ?>" type="application/pdf" width="100%" height="800px">
                                <p>It appears you don't have a PDF plugin for this browser. No biggie... you can
                                    <a href="<?= $pdf_url ?>" target="_blank" style="color:red; text-decoration:none;">
                                        <img src="<?= base_url() ?>img/pdf-icon.png" alt="pdf" width="16" height="16" align="left" /> PDF version
                                    </a>
                                </p>
                            </object>

                        </div>
                    </div>

                    <div class="card-footer small text-muted">
                        If the PDF doesn't load, <a href="<?= $pdf_url ?>" target="_blank" rel="noopener">open it in a new tab</a> or download it.
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    $(function() {
        // Optional: adjust height if header/footer sizes differ
        function adjustHeight() {
            var headerH = $('.content-header').outerHeight() || 0;
            var footerH = $('.main-footer').outerHeight() || 0;
            var offset = headerH + footerH + 80; // padding/margins buffer
            $('#pdfWrapper').css('height', 'calc(100vh - ' + offset + 'px)');
        }
        adjustHeight();
        $(window).on('resize', adjustHeight);
    });
</script>