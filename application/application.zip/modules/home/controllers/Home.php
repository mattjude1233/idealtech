<?php

class Home extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $formdata = $result = '';
        if ($_POST) {
            $formdata = $result = $this->input->post('result');
        }


        if ($result) {
            // explode result by new line
            $result = explode("\n", $result);

            if (!empty($result)) {
                foreach ($result as $key => $value) {
                    // explode value by tab
                    $value = explode("\t", $value);
                    $draw = array();

                    for ($i = 1; $i <= 3; $i++) {
                        if ($value[$i]) {
                            $no = preg_replace('/[^0-9]/', '', $value[$i]);

                            if ($no && strlen($no) == 3) {
                                $no = str_split($no, 1);

                                $to_insert = array(
                                    'draw' => $i,
                                    'no1' => $no[0],
                                    'no2' => $no[1],
                                    'no3' => $no[2],
                                    'date' => date('Y-m-d', strtotime($value[0]))
                                );

                                $check_if_exist = $this->model->getRow('id', "result", "draw = '" . $i . "' AND date = '" . $to_insert['date'] . "'");

                                if (!$check_if_exist) {
                                    $this->model->insert('result', $to_insert);
                                } else {
                                    $this->model->update('result', $to_insert, "id = '" . $check_if_exist['id'] . "'");
                                }
                            }
                        }
                    }
                }
            }
        }

        $data['result'] = $formdata;

        // Get dashboard statistics
        $data['stats'] = array(
            'active_employees' => $this->model->getBySQL("SELECT COUNT(*) as count FROM employees WHERE status = 0", 'row')['count'],
            'regular_employees' => $this->model->getBySQL("SELECT COUNT(*) AS count FROM employees WHERE status = 0 AND hiring_date IS NOT NULL AND hiring_date <= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)", 'row')['count'],
            'probee_employees' => $this->model->getBySQL("SELECT COUNT(*) AS count FROM employees WHERE status = 0 AND hiring_date IS NOT NULL AND hiring_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)", 'row')['count'],
            'pending_leaves' => $this->model->getBySQL("SELECT COUNT(*) as count FROM employee_leave WHERE sv_status = 'pending' OR mgr_status = 'pending' OR (sv_status IS NULL AND mgr_status IS NULL)", 'row')['count'],
            // GET total holidays for current month of the year
            'total_holidays' => $this->model->getBySQL("SELECT COUNT(*) as count FROM holidays WHERE MONTH(date) = MONTH(CURDATE()) AND archived = 0", 'row')['count'],
            'disciplinary_cases' => $this->model->getBySQL("SELECT COUNT(*) as count FROM employee_discipline WHERE status != 2 AND archived != 1", 'row')['count']
        );

        // Get today's absent employees (based on attendance records)
        $today = date('Y-m-d');
        $data['today_absent'] = $this->model->getBySQL("
            SELECT e.emp_fname, e.emp_lname, a.date, a.type, a.absent, a.notes, al.value as type_label
            FROM attendance a 
            JOIN employees e ON a.employee_id = e.id 
            LEFT JOIN admin_lang al ON al.keyid = a.type AND al.keyword = 'attendance|type'
            WHERE a.date = '$today'
            AND (a.absent = 'TRUE' OR (a.punch_in IS NULL AND a.punch_out IS NULL) OR a.type IN ('absent', 'ncns', 'suspended'))
            ORDER BY e.emp_lname ASC, e.emp_fname ASC
            LIMIT 8
        ");

        // Get upcoming leaves (next 7 days)
        $next_week = date('Y-m-d', strtotime('+7 days'));
        $data['upcoming_leaves'] = $this->model->getBySQL("
            SELECT e.emp_fname, e.emp_lname, l.date_from, l.date_to, l.sv_status, l.mgr_status, lt.value as leave_type
            FROM employee_leave l 
            JOIN employees e ON l.employee_id = e.id 
            LEFT JOIN admin_lang lt ON lt.keyid = l.type AND lt.keyword = 'leave|type'
            WHERE DATE(l.date_from) BETWEEN '$today' AND '$next_week'
            AND l.archived = 0
            AND (l.sv_status = 'approved' OR l.mgr_status = 'approved' OR l.status = 'confirmed')
            ORDER BY l.date_from ASC, e.emp_lname ASC
            LIMIT 8
        ");

        // Get upcoming holidays (next 30 days)
        $next_month = date('Y-m-d', strtotime('+90 days'));
        $data['upcoming_holidays'] = $this->model->getBySQL("
            SELECT h.name, h.date, ht.value as type
            FROM holidays h
            LEFT JOIN admin_lang ht ON ht.keyid = h.type AND ht.keyword = 'holiday|type'
            WHERE h.date BETWEEN '$today' AND '$next_month'
            AND h.archived = 0
            ORDER BY h.date ASC
            LIMIT 5
        ");

        // Get active kudos for dashboard
        $data['active_kudos'] = $this->model->getBySQL("SELECT id, name, category, path FROM kudos WHERE active = 1 AND status = 1 LIMIT 1", 'row');

        // Get recent activities (recent leaves, new employees, disciplinary actions, etc.)
        $data['recent_activities'] = array();

        // Recent leave applications (last 7 days)
        $recent_leaves = $this->model->getBySQL("
            SELECT e.emp_fname, e.emp_lname, lt.value AS leave_type, l.sv_status, l.mgr_status, l.date_filed, 'leave' AS activity_type FROM employee_leave AS l JOIN employees AS e ON l.employee_id = e.id LEFT JOIN admin_lang AS lt ON lt.keyid = l.type AND lt.keyword = 'leave|type' WHERE l.archived = 0 AND l.date_filed >= CURDATE() - INTERVAL 7 DAY ORDER BY l.date_filed DESC LIMIT 4;
        ");

        // Recently added employees (last 30 days)
        $recent_employees = $this->model->getBySQL("
            SELECT emp_fname, emp_lname, emp_level, hiring_date, 'employee' as activity_type, hiring_date as date_filed
            FROM employees 
            WHERE DATE(hiring_date) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            AND status != 3
            ORDER BY hiring_date DESC
            LIMIT 4
        ");

        // Recent disciplinary actions (last 14 days)
        $recent_disciplinary = $this->model->getBySQL("
            SELECT e.emp_fname, e.emp_lname, d.violation, d.offense_level, d.date_added, 'disciplinary' as activity_type, d.date_added as date_filed
            FROM employee_discipline d
            JOIN employees e ON d.employee_id = e.id
            WHERE DATE(d.date_added) >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
            AND d.status != 2 AND d.archived != 1
            ORDER BY d.date_added DESC
            LIMIT 3
        ");

        // Merge and sort recent activities
        if (!empty($recent_leaves)) {
            $data['recent_activities'] = array_merge($data['recent_activities'], $recent_leaves);
        }
        if (!empty($recent_employees)) {
            $data['recent_activities'] = array_merge($data['recent_activities'], $recent_employees);
        }
        if (!empty($recent_disciplinary)) {
            $data['recent_activities'] = array_merge($data['recent_activities'], $recent_disciplinary);
        }

        // Sort by date_filed descending
        if (!empty($data['recent_activities'])) {
            usort($data['recent_activities'], function ($a, $b) {
                return strtotime($b['date_filed']) - strtotime($a['date_filed']);
            });
            $data['recent_activities'] = array_slice($data['recent_activities'], 0, 8);
        }

        if (check_function('show_admin_dashboard')) {
            $data['content'] = 'home/index';
        } else {
            $data['content'] = 'home/employee_dashboard';
        }
        $this->display($data);
    }

    function coc($pdf = '')
    {
        $data['content'] = 'home/coc';
        $data['page_title'] = 'Memorandum and COC';
        $data['active_document'] = $pdf;
        $this->display($data);
    }
}
