<?php

class Breakmonitoring extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        // $data['list'] = $this->model->getBySQL("SELECT b.id AS break_id, b.date, b.break_start, b.break_end, b.break_type, e.emp_id, e.emp_fname, e.emp_lname, (SELECT COUNT(*) FROM employee_break b2 WHERE b2.employee_id = b.employee_id AND b2.date = b.date AND b2.break_type = 'break' AND b2.break_start <= b.break_start) AS break_count FROM employee_break AS b LEFT JOIN employees AS e ON e.id = b.employee_id");

        $data['list'] = $this->model->getBySQL("SELECT b.id AS break_id, DATE_FORMAT(b.date, '%Y-%m-%d') AS date, b.break_start, b.break_end, b.break_type, e.emp_id, e.emp_fname, e.emp_lname, (SELECT COUNT(*) FROM employee_break b2 WHERE b2.employee_id = b.employee_id AND DATE_FORMAT(b2.date, '%Y-%m-%d') = DATE_FORMAT(b.date, '%Y-%m-%d') AND b2.break_type = 'break' AND b2.break_start <= b.break_start) AS break_count, ( SELECT SEC_TO_TIME(SUM(TIMESTAMPDIFF(SECOND, b3.break_start, b3.break_end))) FROM employee_break b3 WHERE b3.employee_id = b.employee_id AND DATE_FORMAT(b3.date, '%Y-%m-%d') = DATE_FORMAT(b.date, '%Y-%m-%d') AND b3.break_type = 'break' AND b3.break_end IS NOT NULL ) AS total_break FROM employee_break AS b LEFT JOIN employees AS e ON e.id = b.employee_id");


        $data['page_title'] = 'Break Monitoring';
        $data['content'] = 'breakmonitoring/index';
        $this->display($data);
    }
}
