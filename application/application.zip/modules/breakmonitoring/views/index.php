<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">

            <div class="col-sm-6">
                <?php if (!empty($page_title)) : ?>
                    <h1 class="m-0"><?= ucfirst($page_title) ?></h1>
                <?php endif; ?>

                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                    <li class="breadcrumb-item">Administration</li>
                    <li class="breadcrumb-item active">Break Monitoring</li>
                </ol>
            </div>
        </div>
    </div>
</div>


<!-- Main content -->
<div class="content" <?= empty($page_title) ? "style='padding-top:15px;'" : "" ?>>
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-body">

                        <table class="table table-hover" id="breakMonitoringTable">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Date</th>
                                    <th>Start</th>
                                    <th>End</th>
                                    <th>Duration</th>
                                    <th>Type</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if (!empty($list)) : ?>
                                    <?php foreach ($list as $row) :
                                        $break_duration = '';

                                        if (!empty($row['break_start']) && !empty($row['break_end'])) {
                                            $start = new DateTime($row['break_start']);
                                            $end = new DateTime($row['break_end']);
                                            $interval = $start->diff($end);

                                            $parts = [];
                                            if ($interval->h > 0) {
                                                $parts[] = sprintf('%02d hrs.', $interval->h);
                                            }
                                            if ($interval->i > 0 || empty($parts)) {
                                                $parts[] = sprintf('%02d min.', $interval->i);
                                            }

                                            $break_duration = implode(' ', $parts);
                                        }

                                        $total_break = !empty($row['total_break']) ? $row['total_break'] : 0;

                                        // check if total_break exceed 15 minutes
                                        if ($total_break && strtotime($total_break) > strtotime('00:15:00')) {
                                            $break_duration = 'Overbreak: ';

                                            // show total_break in hrs. and mins.
                                            $total_break_parts = explode(':', $total_break);
                                            if (count($total_break_parts) == 3) {
                                                $hours = (int)$total_break_parts[0];
                                                $mins = (int)$total_break_parts[1];
                                                $parts = [];
                                                if ($hours > 0) {
                                                    $parts[] = sprintf('%02d hrs.', $hours);
                                                }
                                                if ($mins > 0) {
                                                    $parts[] = sprintf('%02d mins.', $mins);
                                                }
                                                $break_duration .= implode(' ', $parts);
                                            } elseif (count($total_break_parts) == 2) {
                                                $mins = (int)$total_break_parts[0];
                                                if ($mins > 0) {
                                                    $break_duration .= sprintf('%02d mins.', $mins);
                                                }
                                            }

                                            $break_duration = "<span class='text-danger'>" . $break_duration . "</span>";
                                        } elseif (empty($break_duration)) {
                                            $break_duration = 'N/A';
                                        }

                                    ?>
                                        <tr>
                                            <td><?= $row['emp_fname'] . ' ' . $row['emp_lname'] ?></td>
                                            <td><?= date('F d, Y', strtotime($row['date'])) ?></td>
                                            <td><?= !empty($row['break_start']) ? date('h:i A', strtotime($row['break_start'])) : '' ?></td>
                                            <td><?= !empty($row['break_end']) ? date('h:i A', strtotime($row['break_end'])) : '' ?></td>
                                            <td><?= $break_duration ?></td>
                                            <td><?= addOrdinalSuffix($row['break_count']) . " " . ucfirst($row['break_type']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No records found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>

            </div>
        </div>
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->

<script>
    $(document).ready(function() {
        $('#breakMonitoringTable').DataTable({
            ordering: true,
            searching: true,
            paging: false,
            info: true,
            responsive: true,
        });
    })
</script>