<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">

            <div class="col-sm-6">
                <?php if (!empty($page_title)) : ?>
                    <h1 class="m-0"><?= ucfirst($page_title) ?></h1>
                <?php endif; ?>

                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                    <li class="breadcrumb-item">Administration</li>
                    <li class="breadcrumb-item active">Employee</li>
                </ol>
            </div>


            <div class="col-sm-6">
                <div class="float-sm-right">
                    <a href="<?= base_url('employee/addemployee') ?>" class="btn btn-pill btn-warning btn-md text-white add_employee-btn"> <i class="fa fa-user-plus"></i> Add Employee</a>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Main content -->
<div class="content" <?= empty($page_title) ? "style='padding-top:15px;'" : "" ?>>
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-2">
                                <input type="text" id="filter_emp_id" name="filter_emp_id" placeholder="Employee ID" class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input type="text" id="filter_emp_name" name="filter_emp_name" placeholder="Employee Name" class="form-control">
                            </div>

                            <div class="col-md-2">
                                <select name="employee_category" id="employee_category" class="form-control">
                                    <option value="">All Roles</option>

                                    <?php
                                    $userlevels = users__lang('level');
                                    if (!empty($userlevels)) :
                                        foreach ($userlevels as $level) :
                                    ?>
                                            <option value="<?= $level['value'] ?>"><?= $level['value'] ?></option>
                                    <?php
                                        endforeach;
                                    endif;
                                    ?>
                                </select>
                            </div>

                            <div class="col-md-2">
                                <select name="employee_status" id="employee_status" class="form-control">
                                    <option value="">All Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                            </div>

                            <div class="col-md-2">
                                <input type="date" id="filter_hired_from" name="filter_hired_from" placeholder="Hired From" class="form-control" title="Hired From Date">
                            </div>

                            <div class="col-md-1">
                                <input type="date" id="filter_hired_to" name="filter_hired_to" placeholder="Hired To" class="form-control" title="Hired To Date">
                            </div>

                            <div class="col-md-1">
                                <div class="d-flex justify-content-end">
                                    <button type="button" id="clear_filters_btn" class="btn btn-secondary" title="Clear Filters"><i class="fa fa-sync"></i></button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card">
                    <div class="card-body">

                        <table class="table" id="employeeTable">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Emp. ID</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Hired Date</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <!-- <th style="width: 40px">Action</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($list)) : ?>
                                    <?php foreach ($list as $employee) : ?>
                                        <tr data-lid="<?= $this->mysecurity->encrypt_url($employee['id']); ?>">
                                            <td><a href="<?= base_url('employee/profile/' . $this->mysecurity->encrypt_url($employee['id'])) ?>"><?= "{$employee['emp_lname']}, {$employee['emp_fname']}" ?></a></td>
                                            <td><?= $employee['emp_id'] ?></td>
                                            <td><?= $employee['email'] ?></td>
                                            <td><?= formatPhone($employee['phone']) ?></td>
                                            <td data-order="<?= strtotime($employee['hiring_date']) ?>"><?= date('M d, Y', strtotime($employee['hiring_date'])) ?></td>
                                            <td><?= users__lang('level', $employee['emp_level']) ?></td>
                                            <td>
                                                <?php
                                                if ($employee['status'] == '0') {
                                                    echo '<span class="badge badge-success">Active</span>';
                                                } elseif ($employee['status'] == '1') {
                                                    echo '<span class="badge badge-danger">Inactive</span>';
                                                }
                                                ?>
                                            </td>
                                                <!-- <td class="text-nowrap">
                                                <a href="javascript:;" class="btn btn-xs btn-danger"> <i class="fa fa-trash"></i></a>
                                            </td> -->
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="5" class="font-italic text-center">No records found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>

            </div>
        </div>


    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->

<script>
    $(document).ready(function() {
        $("#employee_category, #employee_status").select2({
            theme: 'bootstrap4',
        });

        <?php if (!empty($list)) : ?>
            var table = $('#employeeTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
                "dom": 'rtip', // Remove the default search box

                // inactive employee should be last
                "order": [[6, 'asc'], [0, 'asc']]
            });

            // Debounce function
            function debounce(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = function() {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }

            // Custom filter function
            function applyFilters() {
                var empId = $('#filter_emp_id').val().toLowerCase();
                var empName = $('#filter_emp_name').val().toLowerCase();
                var empRole = $('#employee_category').val();
                var empStatus = $('#employee_status').val();
                var hiredFrom = $('#filter_hired_from').val();
                var hiredTo = $('#filter_hired_to').val();

                // Check if any filters are active
                var hasActiveFilters = empId || empName || empRole || empStatus || hiredFrom || hiredTo;

                // Disable/enable paging based on filter status
                if (hasActiveFilters) {
                    table.page.len(-1).draw(); // Show all rows (disable paging)
                } else {
                    table.page.len(10).draw(); // Reset to default page length
                }

                table.rows().every(function() {
                    var data = this.data();
                    var rowEmpId = $(data[1]).text().toLowerCase() || data[1].toLowerCase();
                    var rowEmpName = $(data[0]).text().toLowerCase() || data[0].toLowerCase();
                    var rowEmpRole = $(data[5]).text() || data[5];
                    var rowEmpStatus = $(data[6]).text() || data[6]; // Status column
                    var rowHiredDate = $(data[4]).text() || data[4]; // Hired Date column

                    var showRow = true;

                    // Filter by Employee ID
                    if (empId && rowEmpId.indexOf(empId) === -1) {
                        showRow = false;
                    }

                    // Filter by Employee Name
                    if (empName && rowEmpName.indexOf(empName) === -1) {
                        showRow = false;
                    }

                    // Filter by Role
                    if (empRole && rowEmpRole !== empRole) {
                        showRow = false;
                    }

                    // Filter by Status
                    if (empStatus && rowEmpStatus !== empStatus) {
                        showRow = false;
                    }

                    // Filter by Hired Date Range
                    if (hiredFrom || hiredTo) {
                        // Convert the displayed date format (e.g., "Jan 15, 2023") to Date object
                        var hiredDateObj = new Date(rowHiredDate);

                        if (hiredFrom) {
                            var fromDate = new Date(hiredFrom);
                            if (hiredDateObj < fromDate) {
                                showRow = false;
                            }
                        }

                        if (hiredTo) {
                            var toDate = new Date(hiredTo);
                            // Set to end of day for inclusive comparison
                            toDate.setHours(23, 59, 59, 999);
                            if (hiredDateObj > toDate) {
                                showRow = false;
                            }
                        }
                    }

                    // Show or hide the row
                    if (showRow) {
                        $(this.node()).show();
                    } else {
                        $(this.node()).hide();
                    }
                });

                table.draw(false); // Redraw without changing page
            }

            // Create debounced version of applyFilters
            const debouncedApplyFilters = debounce(applyFilters, 300);

            // Clear filters button click event
            $('#clear_filters_btn').on('click', function() {
                $('#filter_emp_id').val('');
                $('#filter_emp_name').val('');
                $('#employee_category').val('').trigger('change');
                $('#employee_status').val('').trigger('change');
                $('#filter_hired_from').val('');
                $('#filter_hired_to').val('');

                // Re-enable paging when clearing filters
                table.page.len(10).draw();

                // Show all rows
                table.rows().every(function() {
                    $(this.node()).show();
                });
                table.draw(false);
            });

            // Apply filters on keyup with debounce
            $('#filter_emp_id, #filter_emp_name').on('keyup input', function() {
                debouncedApplyFilters();
            });

            // Apply filters when date inputs change
            $('#filter_hired_from, #filter_hired_to').on('change', function() {
                applyFilters();
            });

            // Apply filters when role or status selection changes (no debounce needed for dropdown)
            $('#employee_category, #employee_status').on('change', function() {
                applyFilters();
            });

            $(document).on('click', '.listuser_update--btn', function() {
                var tr = $(this).closest('tr');
                var lid = tr.data('lid');
                window.location.href = '<?= base_url('employee/updateemployee/') ?>' + lid;
            });

            $(document).on('click', '.listuser_schedule--btn', function() {
                var tr = $(this).closest('tr');
                var lid = tr.data('lid');
                window.location.href = '<?= base_url('employee/schedule/') ?>' + lid;
            });
        <?php endif; ?>
    });
</script>