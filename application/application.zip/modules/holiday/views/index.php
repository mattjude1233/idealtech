<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">

            <div class="col-sm-6">
                <?php if (!empty($page_title)) : ?>
                    <h1 class="m-0"><?= ucfirst($page_title) ?></h1>
                <?php endif; ?>

                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                    <li class="breadcrumb-item">Administration</li>
                    <li class="breadcrumb-item active">Holiday</li>
                </ol>
            </div>

            <?php if (check_function('manage_holiday')) : ?>
                <div class="col-sm-6">
                    <div class="float-sm-right">
                        <a href="javascript:;" class="btn btn-pill btn-warning btn-md text-white add_holiday-btn"> <i class="fa fa-user-plus"></i> Add Holiday</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<!-- Main content -->
<div class="content" <?= empty($page_title) ? "style='padding-top:15px;'" : "" ?>>
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                    </div>
                </div>

                <div class="card">

                    <div class="card-body">
                        <div class="row">
                            <!-- dummy div -->
                            <div class="col-12 col-md-4 col-lg-6"></div>

                            <div class="col-12 col-md-4 col-lg-3 text-right">
                                <input type="text" id="table-search-input" placeholder="Search Holiday" class="form-control form-control-sm m-b-5" autocomplete="off">
                            </div>

                            <div class="col-12 col-md-4 col-lg-3 text-right">
                                <input type="text" name="year_holiday" placeholder="From" class="form-control form-control-sm yearpicker" style="width: 100%; float: right;" value="<?= $year ?>" readonly>
                            </div>
                        </div>

                        <table class="table" id="holidayTable">
                            <thead>
                                <tr>
                                    <th>Holiday</th>
                                    <th>Date</th>
                                    <th>Type</th>

                                    <?php if (check_function('manage_holiday')) : ?>
                                        <th>Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($list)) : ?>
                                    <?php foreach ($list as $holiday) : ?>
                                        <tr data-hid="<?= $this->mysecurity->encrypt_url($holiday['id']); ?>">
                                            <td><?= $holiday['name'] ?></td>
                                            <td data-sort="<?= strtotime($holiday['date']) ?>"><?= date('F d, Y', strtotime($holiday['date'])) ?></td>
                                            <td><?= $holiday['type'] ?></td>
                                            <?php if (check_function('manage_holiday')) : ?>
                                                <td>
                                                    <a href="javascript:;" class="btn btn-xs btn-warning update_holiday-btn m-r-5" data-toggle="tooltip" title="Update Holiday"> <i class="fa fa-edit"></i></a>
                                                    <a href="javascript:;" class="btn btn-xs btn-danger cancel_holiday-btn" data-toggle="tooltip" title="Cancel Holiday"> <i class="fa fa-times"></i></a>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No holidays found for the selected year.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>

            </div>
        </div>
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->

<?php if (check_function('manage_holiday')) : ?>
    <div class="modal fade" id="add_holiday-modal" data-backdrop="static" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Holiday</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form id="add_holiday-form">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="holiday">Holiday <span class="text-danger">*</span></label>
                            <input type="text" name="Holiday_Name" id="holiday" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="Holiday_Date">Date <span class="text-danger">*</span></label>
                            <input type="text" name="Holiday_Date" id="holiday_Date" class="form-control datepicker" required>
                        </div>

                        <div class="form-group">
                            <label for="holiday_type">Type <span class="text-danger">*</span></label>
                            <select name="Holiday_Type" id="holiday_type" class="form-control" required>
                                <option value="">Select Type</option>
                                <?= admin__lang_select('holiday', 'type') ?>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <script>
        $(document).ready(function() {

            $(document).on('click', '.add_holiday-btn', function() {
                $('#add_holiday-modal .modal-title').text('Add Holiday');
                $('#add_holiday-form')[0].reset();
                $('#add_holiday-modal').modal('show');

                $(document).off('submit', '#add_holiday-form').on('submit', '#add_holiday-form', function(e) {
                    e.preventDefault();

                    var formdata = $(this).serializeArray();
                    $.ajax({
                        type: 'POST',
                        url: '<?= base_url('holiday/addholiday') ?>',
                        data: formdata,
                        dataType: 'json',
                        success: function(response) {
                            if (response.status == 'success') {

                                // success alert and reload
                                $.alert({
                                    title: 'Success!',
                                    content: response.message,
                                    type: 'green',
                                    buttons: {
                                        OK: {
                                            text: 'OK',
                                            btnClass: 'btn-green',
                                            action: function() {
                                                location.reload();
                                            }
                                        }
                                    }
                                });

                            } else {
                                $.alert({
                                    title: 'Error!',
                                    content: response.message,
                                    type: 'red',
                                    buttons: {
                                        Ok: {
                                            text: 'Ok',
                                            btnClass: 'btn-red',
                                            action: function() {
                                                $('#btn-save').buttonLoader('stop');
                                            }
                                        }
                                    }
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            $.alert({
                                title: 'Error!',
                                content: 'An error occurred while processing your request. Please try again later.',
                                type: 'red',
                                buttons: {
                                    Ok: {
                                        text: 'Ok',
                                        btnClass: 'btn-red',
                                        action: function() {
                                            $('#btn-save').buttonLoader('stop');
                                        }
                                    }
                                }
                            });
                        }
                    });
                });
            });

            $(document).on('click', '.update_holiday-btn', function() {
                var id = $(this).closest('tr').data('hid');

                // change modal title
                $('#add_holiday-modal .modal-title').text('Update Holiday');

                $.ajax({
                    type: 'POST',
                    url: '<?= base_url('holiday/getholiday') ?>',
                    data: {
                        holidayid: id
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 'success') {
                            $('#add_holiday-form')[0].reset();
                            $('#add_holiday-modal').modal('show');

                            // populate form fields with response data
                            $('#holiday').val(response.data.name);
                            $('#holiday_Date').val(response.data.date);
                            $('#holiday_type').val(response.data.type);

                            $(document).off('submit', '#add_holiday-form').on('submit', '#add_holiday-form', function(e) {
                                e.preventDefault();

                                var formdata = $(this).serializeArray();
                                formdata.push({
                                    name: 'holidayid',
                                    value: id
                                });


                                // process form submission ajax
                                $.ajax({
                                    type: 'POST',
                                    url: '<?= base_url('holiday/updateholiday') ?>',
                                    data: formdata,
                                    dataType: 'json',
                                    success: function(response) {
                                        if (response.status == 'success') {

                                            // success alert and reload
                                            $.alert({
                                                title: 'Success!',
                                                content: response.message,
                                                type: 'green',
                                                buttons: {
                                                    OK: {
                                                        text: 'OK',
                                                        btnClass: 'btn-green',
                                                        action: function() {
                                                            location.reload();
                                                        }
                                                    }
                                                }
                                            });

                                        } else {
                                            $.alert({
                                                title: 'Error!',
                                                content: response.message,
                                                type: 'red',
                                                buttons: {
                                                    Ok: {
                                                        text: 'Ok',
                                                        btnClass: 'btn-red',
                                                        action: function() {
                                                            $('#btn-save').buttonLoader('stop');
                                                        }
                                                    }
                                                }
                                            });
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        $.alert({
                                            title: 'Error!',
                                            content: 'An error occurred while processing your request. Please try again later.',
                                            type: 'red',
                                            buttons: {
                                                Ok: {
                                                    text: 'Ok',
                                                    btnClass: 'btn-red',
                                                    action: function() {
                                                        $('#btn-save').buttonLoader('stop');
                                                    }
                                                }
                                            }
                                        });
                                    }
                                });


                            });

                        } else {
                            $.alert({
                                title: 'Error!',
                                content: response.message,
                                type: 'red'
                            });
                        }
                    }
                });
            });

            $(document).on('click', '.cancel_holiday-btn', function() {
                var id = $(this).closest('tr').data('hid');

                $.confirm({
                    title: 'Cancel Holiday',
                    content: 'Are you sure you want to cancel this holiday?',
                    type: 'red',
                    buttons: {
                        confirm: {
                            text: 'Yes',
                            btnClass: 'btn-red',
                            action: function() {
                                $.ajax({
                                    type: 'POST',
                                    url: '<?= base_url('holiday/cancelholiday') ?>',
                                    data: {
                                        holidayid: id
                                    },
                                    dataType: 'json',
                                    success: function(response) {
                                        if (response.status === 'success') {
                                            $.alert({
                                                title: 'Success!',
                                                content: response.message,
                                                type: 'green'
                                            });
                                            location.reload();
                                        } else {
                                            $.alert({
                                                title: 'Error!',
                                                content: response.message,
                                                type: 'red'
                                            });
                                        }
                                    }
                                });
                            }
                        },
                        cancel: function() {}
                    }
                });
            });
        })
    </script>
<?php endif; ?>

<script>
    $(document).ready(function() {

        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true,
            todayHighlight: true,
        });

        $('.yearpicker').datepicker({
            format: 'yyyy',
            viewMode: 'years',
            minViewMode: 'years',
            autoclose: true,
            todayHighlight: true,
        }).on('changeDate', function(e) {
            var year = e.date.getFullYear();
            window.location.href = "<?= base_url('holiday/index/') ?>" + year;
        });

        <?php if (!empty($list)) : ?>
            $('#holidayTable').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,

                // order by date ascending
                "order": [
                    [1, 'asc']
                ],
                initComplete: function() {
                    const $wrap = $(this.api().table().container());
                    $wrap.find('.dataTables_filter').hide(); // hide default search
                }
            });

            $('#table-search-input').on('input', function() {
                $('#holidayTable').DataTable().search($(this).val()).draw();
            });
        <?php endif; ?>
    });
</script>